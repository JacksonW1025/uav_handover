import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
import numpy as np
from recovery import sustained,recovery

def test_stage_boundary_and_insufficient_observation():
    t=np.arange(0,4000001,10000);good=np.ones(len(t),bool)
    assert sustained(t,good,good,0,1500000,2,.02)['status']=='INSUFFICIENT_OBSERVATION'
    assert sustained(t,good,good,0,3000000,2,.02)['confirmed_us']==2000000
    good[t<1500000]=False
    assert sustained(t,good,np.ones(len(t),bool),0,3000000,2,.02)['status']=='NOT_SETTLED'
    assert sustained(t,good,np.ones(len(t),bool),0,4000001,2,.02)['time_s']==1.5

def test_missing_data_does_not_count_as_continuous():
    t=np.r_[np.arange(0,1000000,10000),np.arange(3000000,4000000,10000)]
    assert sustained(t,np.ones(len(t),bool),np.ones(len(t),bool),0,4000000,2,.02)['status']=='INSUFFICIENT_OBSERVATION'

def test_joint_condition_and_between_position_samples_angular_spike():
    t=np.arange(0,3000000,10000);a=np.arange(0,3000000,5000)
    l={'timestamp':t,**{k:np.zeros(len(t)) for k in ['x','y','z','vx','vy','vz']}}
    l['z'][:]=-3
    w={'timestamp':a,**{f'xyz[{i}]':np.zeros(len(a)) for i in range(3)}}
    w['xyz[0]'][a==1505000]=.2
    cfg={'position_reference_ned_m':[0,0,-3],'velocity_reference_ned_m_s':[0,0,0],
         'angular_velocity_reference_frd_rad_s':[0,0,0],'position_threshold_m':.2,
         'velocity_threshold_m_s':.1,'angular_velocity_threshold_rad_s':.1,'dwell_s':2,'max_observation_gap_s':.02}
    r=recovery(l,w,cfg,0,3000000)
    assert r['position_band_entry']['status']=='SETTLED'
    assert r['joint_recovery']['status']=='NOT_SETTLED'
    w['xyz[0]'][:]=0;l['vx'][:]=.2
    assert recovery(l,w,cfg,0,3000000)['joint_recovery']['status']=='NOT_SETTLED'

def test_source_gap_breaks_even_with_fresh_other_topic_and_no_future_alignment():
    # 21ms position gap: angular samples fill every millisecond. At the last
    # held point age is exactly20ms, so age checks alone would miss this gap.
    t=np.r_[np.arange(0,1000000,1000),np.arange(1020000,3000000,1000)]
    a=np.arange(0,3000000,1000)
    l={'timestamp':t,**{k:np.zeros(len(t)) for k in ['x','y','z','vx','vy','vz']}};l['z'][:]=-3
    w={'timestamp':a,**{f'xyz[{i}]':np.zeros(len(a)) for i in range(3)}}
    cfg={'position_reference_ned_m':[0,0,-3],'velocity_reference_ned_m_s':[0,0,0],
         'angular_velocity_reference_frd_rad_s':[0,0,0],'position_threshold_m':.2,
         'velocity_threshold_m_s':.1,'angular_velocity_threshold_rad_s':.1,'dwell_s':2,'max_observation_gap_s':.02}
    result=recovery(l,w,cfg,0,3000000)['joint_recovery']
    assert result['status']=='INSUFFICIENT_OBSERVATION'
    assert result['true_first_recovery_uncertain']
    # A future first angular sample cannot provide evidence before it exists.
    w={k:v[a>=1000000] for k,v in w.items()}
    assert recovery(l,w,cfg,0,3000000)['joint_recovery']['status']=='INSUFFICIENT_OBSERVATION'

def test_first_verifiable_recovery_after_gap():
    t=np.r_[np.arange(0,1000000,10000),np.arange(1100000,4000000,10000)]
    r=sustained(t,np.ones(len(t),bool),np.ones(len(t),bool),0,4000000,2,.02)
    assert r['status']=='SETTLED' and r['entry_us']==1100000
    assert r['true_first_recovery_uncertain']
