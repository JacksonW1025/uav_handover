# 2026-10-11 准备阶段候选版本

本轮仅进行本机 headless SITL 工程准备，不开展正式状态策略对照、P1–P4 或实飞。历史 P0 总审计仍为 FAIL，未改写历史运行与指标。

## 范围与版本

修改前的工具、研究源码、文档、配置、补丁和锁清单保存在 `data/preparation-20261011/baseline/project-source.tar.gz`；两套 PX4 差异、未跟踪源码和二进制哈希分别归档。新候选归档在 `candidate/`，批次身份及预登记计划在 `batch-01/candidate.json`、`batch-01/plan.json`。

本轮不修改策略权重、机体动力学、native 频率、原 executor 阈值和原联合恢复标准。4 ms 保持时延目标，没有增加数值硬 FAIL 门槛。

## 已实施

1. 两套 Gazebo 桥的 ESC、wheel、servo 和 gimbal 互斥锁改为对象构造时初始化；删除 `init()` 内的延后初始化，避免回调注册后仍访问未初始化的锁。此修改修复明确的初始化顺序风险，尚不能证明与历史崩溃同根。未新增析构时销毁锁，避免共享 transport 回调尚未退出时销毁；整个对象仍由原桥生命周期管理。
2. 原始 `sensor_baro` 和选中 `vehicle_air_data` 导出到对应 ROS overlay。运行器要求原始/选中气压有限且为正、device ID 匹配、位置估计有效、接收年龄不超过 0.5 s，并持续 2 s；三个原生发布时钟也必须推进至少 2 s。就绪失败保留具体原因，不自动重启重试，不关闭解锁健康检查。
3. 新增 `--startup-only`：只启动、等待传感器就绪、保存诊断并退出，完全不进入解锁和飞行流程。Gazebo pressure 原始 transport 输出、原始气压、选中气压和估计值均保存。
4. 推理记录增加位置/姿态采样时间、主机单调计算前后时间、动作发布仿真/主机时间。ESC 输出桥记录 mixer 实际选中的采样时间、输出转速、transport Publish 返回值及累计年龄桶、重复/倒退计数。只增加观测，没有改变排队或输出策略。
5. 子进程允许生成 core；当前系统 core_pattern 指向 apport，不能据此保证每次崩溃都在运行目录产生 core。记录实际配置，未改系统全局 core 设置。

复现入口仍为 `tools/apply_research.py`，它调用 `tools/apply_preparation.py`。补丁已更新；修改前副本在 baseline 内。两套构建通过，源码连续两次适配保持字节幂等；11 项 Python 检查通过，SampleClock 和 StateOps 的 ASAN/UBSAN 测试通过。

## 测量语义

- 角速度、姿态、位置的 timestamp_sample 各有含义。采样偏差不自动等于计算调度迟滞；正的“gyro minus position”表示位置采样更早。
- ESC 桥记录的是输出 provider 选中命令以及 Gazebo transport 发布成功，不是电机物理更新确认。现有 ESC feedback 订阅的也是 command/motor_speed，不能充当独立电机消费证据。
- 重复选中同一采样可以表示命令保持，不等于重复 GRU 提交。
- ULog 分位数和逐行匹配只覆盖记录行；输出年龄桶等累计数仅覆盖至最后记录的计数快照。全程计数末值若没有可靠终态确认，不应称为绝对完整。
- 控制链路的物理步消费确认、训练延迟鲁棒性、硬 deadline 和精确历史观测对齐尚未完成。本轮不以测量成功声明这些能力已通过。

## 冒烟结果

classic 与 RAPTOR 的不解锁冷启动检查均 PASS；一次 RAPTOR 短时 C→N→C 飞行及原严格单轮分析 PASS。该神经发布窗口记录到位置和姿态采样各一次晚于角速度 4 ms，说明先前提出的混合时刻现象确实存在；该测量不能单独证明会导致失稳。

该轮神经持权区间中，ESC 桥记录行的采集至选择年龄 P99=4 ms、最大=4 ms；神经动作发布行的年龄最大=8 ms。两者覆盖不同记录集合，不能据此声称所有旧动作均消费。主机时间匹配的发布至桥时延最大约 5.11 ms，进一步说明仿真时钟年龄与主机耗时不能混为一谈。详见 `data/prep-20261011-smoke-flight-raptor/preparation-trace.json`。

## 预登记批次

批次为 20 次冷启动（classic/RAPTOR 各 10 次）和七类场景各 3 次。所有尝试均进入 results；任一失败即停止该候选进行诊断，未执行项目保持 NOT_RUN。该规模用于工程筛查，不构成可靠性认证，也不构成正式因果对照。

批次执行状态以 `data/preparation-20261011/batch-01/results.json` 为准。即使该批次通过，也不能自动关闭历史 P0 未决项或证明电机物理步消费。

## 首批失败与进一步诊断

`batch-01` 在 startup-05（classic，不解锁）停止：此前 4 次通过，该次 PX4 DDS 位置/姿态遥测未就绪，随后 36 项 NOT_RUN。原生检查证明 Gazebo pressure、sensor_baro、vehicle_air_data 正常，但 ULog 完全没有 sensor_gyro、vehicle_imu 和姿态/位置估计数据。这不是一次气压计缺失，也没有进程崩溃。该批次运行期间另修正了飞行失败处理顺序：空中失败立即走原降落/清理流程，跳过新增的阻塞诊断；因此 batch-01 的 candidate_unchanged=false，如实保留，不能作为最终冻结版本批次。

两套 bridge 随后增加 IMU/baro/mag 的原子回调计数，并保存 Gazebo publisher/subscriber 地址。成功诊断轮自动选择的端点为 Docker 网桥 172.17.0.1。多网卡选择是调查线索，尚未证明其导致失败。

注意观测干预：[Gazebo 8.11.0 IMU 实现](https://github.com/gazebosim/gz-sim/blob/gz-sim8_8.11.0/src/systems/imu/Imu.cc)在存在订阅连接时才更新传感器。因此额外 `gz topic -e` 订阅可能改变启动行为；带额外原始传感器订阅的诊断轮，不可代替只有 bridge 消费者的最终验收。Gazebo 官方支持通过 [GZ_IP 指定本机通信地址](https://gazebosim.org/api/transport/15/envvars.html)，后续本机候选将明确冻结这一条件，不以配置更改宣称历史根因已证明。
