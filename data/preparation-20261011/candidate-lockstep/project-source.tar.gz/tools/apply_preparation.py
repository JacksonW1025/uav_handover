"""Preparation-only lifecycle fixes and output tracing; called by apply_research."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def replace(path,old,new):
    text=path.read_text()
    if new in text:return
    if old not in text:raise RuntimeError('preparation anchor missing: '+str(path))
    path.write_text(text.replace(old,new,1))
def apply():
    for variant in ['classic','raptor']:
        root=ROOT/'uav_lab/.local/checkouts'/('px4-'+variant)
        if variant == 'raptor':
            scheduler=root/'platforms/posix/src/px4/common/lockstep_scheduler/src/lockstep_scheduler.cpp'
            scheduler.write_bytes((ROOT/'research/platform/lockstep_scheduler.cpp').read_bytes())
        bridge=root/'src/modules/simulation/gz_bridge'
        for name in ['GZMixingInterfaceESC','GZMixingInterfaceWheel','GZMixingInterfaceServo','GZGimbal']:
            replace(bridge/(name+'.hpp'),'pthread_mutex_t _node_mutex;',
                    'pthread_mutex_t _node_mutex = PTHREAD_MUTEX_INITIALIZER;')
            p=bridge/(name+'.cpp');s=p.read_text()
            s=s.replace('\tpthread_mutex_init(&_node_mutex, nullptr);\n', '')
            p.write_text(s)
        replace(bridge/'GZBridge.hpp','#include <gz/math.hh>','#include <atomic>\n#include <gz/math.hh>')
        replace(bridge/'GZBridge.hpp','private:\n','private:\n    std::atomic<uint64_t> _research_imu_callbacks{0}, _research_baro_callbacks{0}, _research_mag_callbacks{0};\n')
        for signature, counter in [('void GZBridge::airPressureCallback(const gz::msgs::FluidPressure &msg)', 'baro'), ('void GZBridge::magnetometerCallback(const gz::msgs::Magnetometer &msg)', 'mag')]:
            replace(bridge/'GZBridge.cpp',signature+'\n{',signature+'\n{\n    _research_'+counter+'_callbacks.fetch_add(1, std::memory_order_relaxed);')
        stamp='static_cast<uint64_t>(msg.header().stamp().sec()) * 1000000ULL + msg.header().stamp().nsec() / 1000' if variant=='raptor' else 'hrt_absolute_time()'
        imu_anchor='void GZBridge::imuCallback(const gz::msgs::IMU &msg)\n{\n\tconst uint64_t timestamp = '+stamp+';'
        replace(bridge/'GZBridge.cpp',imu_anchor,imu_anchor+'\n    _research_imu_callbacks.fetch_add(1, std::memory_order_relaxed);')
        replace(bridge/'GZBridge.cpp','int GZBridge::print_status()\n{',
            'int GZBridge::print_status()\n{\n    PX4_INFO("Research callbacks: imu=%llu baro=%llu mag=%llu", (unsigned long long)_research_imu_callbacks.load(), (unsigned long long)_research_baro_callbacks.load(), (unsigned long long)_research_mag_callbacks.load());')
        dds=root/'src/modules/uxrce_dds_client/dds_topics.yaml'
        replace(dds,'publications:\n','''publications:
  # Preparation readiness: actual raw and selected barometer data.
  - topic: /fmu/out/sensor_baro
    type: px4_msgs::msg::SensorBaro
  - topic: /fmu/out/vehicle_air_data
    type: px4_msgs::msg::VehicleAirData
''')
    root=ROOT/'uav_lab/.local/checkouts/px4-raptor'
    replace(root/'msg/CMakeLists.txt','\tResearchActuator.msg','\tResearchOutput.msg\n\tResearchActuator.msg')
    replace(root/'src/lib/mixer_module/mixer_module.hpp',
        '\tconst actuator_armed_s &armed() const { return _armed; }',
        '''// SITL research: sample actually selected by the configured output provider.
#ifdef __PX4_POSIX
    hrt_abstime researchSelectedSampleTimestamp() const {
        hrt_abstime sample=0;
        if (_function_allocated[0]) _function_allocated[0]->getLatestSampleTimestamp(sample);
        return sample;
    }
#endif
\tconst actuator_armed_s &armed() const { return _armed; }''')
    esc=root/'src/modules/simulation/gz_bridge/GZMixingInterfaceESC.cpp'
    replace(esc,'#include "GZMixingInterfaceESC.hpp"',
        '#include "GZMixingInterfaceESC.hpp"\n#include <uORB/topics/research_output.h>\n#include <time.h>')
    replace(esc,'\t\t\treturn _actuators_pub.Publish(rotor_velocity_message);',
        '''            const bool published=_actuators_pub.Publish(rotor_velocity_message);
            // This confirms bridge selection and transport publication, NOT motor physics consumption.
            static uint64_t attempts=0, successes=0, repeated=0, regressed=0, negative=0, previous=0;
            static uint64_t bins[8]{};
            const uint64_t sample=_mixing_output.researchSelectedSampleTimestamp();
            const uint64_t now=hrt_absolute_time();
            const int64_t age=static_cast<int64_t>(now)-static_cast<int64_t>(sample);
            ++attempts;if(published)++successes;
            if(sample && previous==sample)++repeated;
            if(sample && previous && sample<previous)++regressed;
            if(sample) {
                previous=sample;
                if(age<0)++negative;
                else {
                    const int64_t limits[7]={0,4000,8000,12000,20000,40000,100000};
                    unsigned i=0;while(i<7 && age>limits[i])++i;++bins[i];
                }
            }
            struct timespec wall{};clock_gettime(CLOCK_MONOTONIC,&wall);
            research_output_s trace{};
            trace.timestamp=now;trace.timestamp_sample=sample;
            trace.wall_monotonic_ns=static_cast<uint64_t>(wall.tv_sec)*1000000000ULL+wall.tv_nsec;
            trace.attempts_total=attempts;trace.published_total=successes;
            trace.repeated_sample_total=repeated;trace.regressed_sample_total=regressed;trace.negative_age_total=negative;
            for(unsigned i=0;i<8;i++)trace.age_bins[i]=bins[i];
            trace.transport_published=published;trace.armed=_mixing_output.armed().armed;
            for(unsigned i=0;i<4 && i<active_output_count;i++)trace.motor_speed[i]=outputs[i];
            static uORB::Publication<research_output_s> trace_pub{ORB_ID(research_output)};
            trace_pub.publish(trace);
            return published;''')
if __name__=='__main__':apply()
